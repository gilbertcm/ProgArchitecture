package components;

public class Demux {
	private int value; //the value this demux will enable

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
}